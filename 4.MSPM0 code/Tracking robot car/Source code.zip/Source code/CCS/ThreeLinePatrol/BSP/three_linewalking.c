#include "ti_msp_dl_config.h"
#include "three_linewalking.h"
#include "app_motion.h"
#include "stdio.h"

/**
* @brief         ��ȡѲ��״̬	Get line patrol status
* @param[in]     int *p_iL, int *p_iM,  int *p_iR  ��·Ѳ��λָ��	Three-way line patrol pointer
* @param[out]    void
* @retval        void
*/
void three_GetLineWalking(int *p_iL, int *p_iM, int *p_iR)
{
	*p_iL = LineWalk_L_IN;
	*p_iM = LineWalk_M_IN;
	*p_iR = LineWalk_R_IN;
	printf("L = %d M = %d R = %d\r\n",*p_iL,*p_iM,*p_iR);
}

/**
* @brief         Ѳ��ģʽ�˶�	Line following mode movement
* @param[in]     void
* @param[out]    void
* @retval        void
*/
void three_LineWalking(void)
{
	int LineL = 0, LineM = 0, LineR = 0;

	three_GetLineWalking(&LineL, &LineM, &LineR);	//��ȡ���߼��״̬	Get black line detection status
	Motion_Set_Pwm(0,0,0,0);
  if( LineL == HIGH &&  LineM == HIGH) //����ֱ��	Continue straight
    {  
		Motion_Set_Pwm(800,800,800,800);
	}
    else if ( LineM == HIGH && LineR == HIGH) //����ֱ��	Continue straight
    {  
		Motion_Set_Pwm(800,800,800,800);
	}
    else if (LineL == HIGH ) //��ת	Turn left
    {   
		Motion_Set_Pwm(-800,1100,-800,1100);
	}
	else if (LineR == HIGH) //��ת	Turn right
    {   
		Motion_Set_Pwm(1100,-800,1100,-800);
	}
    else //if(LineM == HIGH ) //ǰ��	go ahead
    {  
		Motion_Set_Pwm(900,900,900,900);
	}	

}



