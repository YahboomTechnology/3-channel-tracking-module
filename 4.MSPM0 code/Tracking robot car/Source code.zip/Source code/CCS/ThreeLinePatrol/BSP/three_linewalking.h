#ifndef __THREE_LINEWALKING_H__
#define __THREE_LINEWALKING_H__	

#include "ti_msp_dl_config.h"
#include "three_linewalking.h"

/*
	�ӳ���������ǰ���� ��ൽ�ұ�Ѳ�ߴ�����˳��Ϊ  L  M  R
	Looking forward from the rear of the vehicle: The order of the line-following sensors from left to right is L M R
*/

#define LOW		(0)
#define HIGH	(1)


#define LineWalk_L_IN		( ( ( DL_GPIO_readPins(Sensor_PORT,Sensor_X3_PIN) & Sensor_X3_PIN ) > 0 ) ? 1 : 0 )
#define LineWalk_M_IN		( ( ( DL_GPIO_readPins(Sensor_PORT,Sensor_X2_PIN) & Sensor_X2_PIN ) > 0 ) ? 1 : 0 )
#define LineWalk_R_IN		( ( ( DL_GPIO_readPins(Sensor_PORT,Sensor_X1_PIN) & Sensor_X1_PIN ) > 0 ) ? 1 : 0 )



void three_GetLineWalking(int *p_iL, int *p_iM, int *p_iR);
void three_LineWalking(void);


#endif


