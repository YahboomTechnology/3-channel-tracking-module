#include "ti_msp_dl_config.h"
#include "delay.h"
#include "usart.h"
#include "bsp_motor.h"
#include "app_motion.h"
#include "three_linewalking.h"

int main(void)
{
    USART_Init();
    while (1)
    {
		three_LineWalking();		//��·Ѳ��ģʽ  Three-way line patrol mode
    }
}
