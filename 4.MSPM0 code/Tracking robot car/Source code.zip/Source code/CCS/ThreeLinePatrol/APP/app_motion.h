#ifndef __APP_MOTION_H__
#define __APP_MOTION_H__

#include "ti_msp_dl_config.h"
#include "stdint.h"


void Motion_Set_Pwm(int16_t Motor_1, int16_t Motor_2, int16_t Motor_3, int16_t Motor_4);

#endif
