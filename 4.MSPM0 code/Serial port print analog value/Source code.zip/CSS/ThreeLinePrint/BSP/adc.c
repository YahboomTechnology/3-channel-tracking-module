#include "adc.h"
volatile bool gCheckADC;//ADC采集成功标志位	ADC acquisition success flag

//读取ADC的数据	Read ADC data
unsigned int adc_getValue(uint8_t ch)
{
        unsigned int gAdcResult = 0;

        //软件触发ADC开始转换	Software triggers ADC to start conversion
        DL_ADC12_startConversion(ADC12_0_INST);
        //如果当前状态为正在转换中则等待转换结束	If the current state is in transition, wait for the transition to end.
        while (false == gCheckADC) {
            __WFE();
        }
        //获取数据	Get data
        gAdcResult = DL_ADC12_getMemResult(ADC12_0_INST, ch);

        //清除标志位	Clear flag
        gCheckADC = false;

        return gAdcResult;
}

//ADC中断服务函数	ADC interrupt service function
void ADC12_0_INST_IRQHandler(void)
{
	//查询并清除ADC中断	Query and clear ADC interrupt
	switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST))
	{
		//检查是否完成数据采集	Check whether data collection is completed
		case DL_ADC12_IIDX_MEM0_RESULT_LOADED:
						gCheckADC = true;//将标志位置1	Set the flag position to 1
						break;
		default:
						break;
	}
}

//获取通道ch的转换值	Get the conversion value of channel ch
//取times次,然后平均	Take times and then average
uint16_t T_Get_Adc_Average(uint8_t ch,uint8_t times)
{
	uint32_t temp_val=0;
	uint8_t t;
	for(t=0;t<times;t++)
	{
		temp_val+=adc_getValue(ch);
		delay_ms(5);
	}
	return temp_val/times;
}
