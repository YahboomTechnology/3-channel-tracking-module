#ifndef	__ADC_H__
#define __ADC_H__

#include "ti_msp_dl_config.h"
#include "stdint.h"
#include "delay.h"


unsigned int adc_getValue(uint8_t ch);
uint16_t T_Get_Adc_Average(uint8_t ch,uint8_t times);

#endif
