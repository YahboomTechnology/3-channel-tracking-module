#include "stm32f10x.h"
#include "SysTick.h"
#include "UART.h"
#include "ADC.h"

int main(void)
{  
    SysTick_Init();//滴答定时器初始化
    UART1_Init();//UART1初始化
    ADC1_Init();//ADC1初始化
    
    printf("Trail module!\n");//打印Trail module！
    
    while(1)
    {
        Trail_X_Y_Z_Data();//获取JoyStick X Y轴数据 并打印相关信息到串口
    }
}
